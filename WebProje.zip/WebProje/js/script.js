// Bars butonuna tıklanarak açılacak menü
const barsBtn = document.querySelector('.bars-btn');
const cartContainer = document.querySelector('.cart-items-conteiner');

barsBtn.addEventListener('click', () => {
  cartContainer.classList.toggle('active'); // 'active' sınıfını ekleyerek menüyü göster/gizle
});

// Person butonuna tıklanarak yapılacak işlem
const personBtn = document.querySelector('.cart-btn');

personBtn.addEventListener('click', () => {
  alert("Kullanıcı bilgileri açılacak."); // Örneğin bir uyarı gösterelim
});
